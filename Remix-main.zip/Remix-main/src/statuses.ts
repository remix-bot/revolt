// rename this to statuses.ts and edit as needed
export const statuses = [
	{ presence: "Online", text: `%help` },
	{ presence: "Online", text: `%help | Servers: 62 Users: 1660` },
];