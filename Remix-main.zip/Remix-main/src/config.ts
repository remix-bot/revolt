export const config = {
	prefix: "%",
	developers: ["01FVB1ZGCPS8TJ4PD4P7NAFDZA"],
};
